package reading_Data_From_Excel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckoutTest extends BaseTest{
	

	public WebDriver driver;
	@Test(dataProvider = "Sheet1", dataProviderClass = ExcelData.class)
	public void loginTest(String username,String password) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-blink-features=AutomationControlled");
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
		options.setExperimentalOption("useAutomationExtension", false);

		// Disable password manager
		Map<String, Object> prefs = new HashMap<>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);
		test = extent.createTest("Checkout Process Test");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.get("https://www.saucedemo.com/v1/");
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		String title = driver.getTitle();
		Assert.assertEquals(title, "Swag Labs");
		Thread.sleep(3000);
			WebElement filter = driver.findElement(By.className("product_sort_container"));
		Select select= new Select(filter);
		select.selectByVisibleText("Price (low to high)");
		Thread.sleep(3000); 

        driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']/../../..//button")).click();
        

        WebElement cartItem = driver.findElement(By.className("inventory_item_name"));
        Assert.assertEquals(cartItem.getText(), "Sauce Labs Onesie");

       
        driver.findElement(By.className("shopping_cart_container")).click();
        
        Thread.sleep(2000);
        driver.findElement(By.linkText("CHECKOUT")).click();
        test.log(Status.INFO, "Clicked on checkout button");

        driver.findElement(By.id("first-name")).sendKeys("Rohit");
        driver.findElement(By.id("last-name")).sendKeys("Raina");
        driver.findElement(By.id("postal-code")).sendKeys("54789");
        test.log(Status.INFO, "Entered required details");

        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@value='CONTINUE']")).click();
        driver.findElement(By.linkText("FINISH")).click();
        test.log(Status.INFO, "Cliked on finish to complete purchase");

        WebElement confirmation = driver.findElement(By.className("complete-header"));
        Assert.assertEquals(confirmation.getText(), "THANK YOU FOR YOUR ORDER");
	driver.quit();
	}
	
}
