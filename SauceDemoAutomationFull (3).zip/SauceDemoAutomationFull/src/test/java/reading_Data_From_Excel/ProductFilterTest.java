package reading_Data_From_Excel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProductFilterTest extends BaseTest{
	
	

	public WebDriver driver;
	@Test(dataProvider = "Sheet1", dataProviderClass = ExcelData.class)
	public void loginTest(String username,String password) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-blink-features=AutomationControlled");
		options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
		options.setExperimentalOption("useAutomationExtension", false);

		// Disable password manager
		Map<String, Object> prefs = new HashMap<>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);

		test = extent.createTest("Product Filter Test");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.get("https://www.saucedemo.com/v1/");
		driver.findElement(By.id("user-name")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("login-button")).click();
		String title = driver.getTitle();
		Assert.assertEquals(title, "Swag Labs");
		Thread.sleep(3000);
			WebElement filter = driver.findElement(By.className("product_sort_container"));
		Select select= new Select(filter);
		select.selectByVisibleText("Price (low to high)");
		test.log(Status.INFO, "Product filter sort by Price (low to high) applied ");
		Thread.sleep(3000);
		List<WebElement> items = driver.findElements(By.className("inventory_item_name"));
        System.out.println("Filtered Product Names:");
        test.log(Status.INFO, "Product arranged as per filter");
        for (WebElement item : items) {
            System.out.println(item.getText());
            
        }
        test.log(Status.INFO, "Printed product names aśper filter");
	driver.quit();
        }
	@AfterSuite
    public void flushReport() {
        extent.flush();
    }
}
